package org.uniquindio.proyectofinalcodigo.model;

public enum TipoAtraccion {
    MECANICA_TERRESTRE, MECANICA_DE_ALTURA, ACUATICA, SHOW, OTRO 
}
